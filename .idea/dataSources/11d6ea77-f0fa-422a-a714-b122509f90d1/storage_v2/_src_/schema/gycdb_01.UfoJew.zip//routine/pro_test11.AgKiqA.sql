create
    definer = gyc@`%` procedure pro_test11(IN n int)
begin
    declare sum int default 0 ;
    declare i int default 0;
    c:loop
        set sum = sum+i;
        set i = i+1;
        if i>n then
            leave c;
        end if;
    end loop c;
    select sum;
end;

