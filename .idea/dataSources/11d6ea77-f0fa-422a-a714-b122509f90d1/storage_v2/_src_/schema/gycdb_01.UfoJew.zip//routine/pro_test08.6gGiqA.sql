create
    definer = gyc@`%` procedure pro_test08(IN month_val int, OUT MON varchar(10))
begin
        case
            when month_val>=1 and month_val<=3 then
                set MON='第一季度';
            when month_val>=4 and month_val<=6 then
                set MON='第二季度';
            when month_val>=7 and month_val<=9 then
                set MON='第三季度';
            else
                set MON='第四季度';
        end case ;
    end;

