create
    definer = gyc@`%` procedure pro_test02()
begin
        declare num int default 10;
        select concat('num的值为:',num);
    end;

