create
    definer = gyc@`%` procedure pro_test12()
begin
    declare e_id int(11);
    declare e_name varchar(50);
    declare e_age int(3);
    declare e_sal int(11);
    declare has_next int default 1;
    declare cur cursor for (select * from emp);
    DECLARE EXIT HANDLER FOR NOT FOUND SET has_next=0;# 当拿不到数据的时候就会触发句柄
    # 上面这句话要声明在游标的正下方
    open cur;
        REPEAT
            FETCH cur into e_id,e_name,e_age,e_sal;
            select concat('id=',e_id,',name',e_name,',age',e_age,',salary',e_sal);
            until has_next=0
        end REPEAT;
    close cur;
end;

