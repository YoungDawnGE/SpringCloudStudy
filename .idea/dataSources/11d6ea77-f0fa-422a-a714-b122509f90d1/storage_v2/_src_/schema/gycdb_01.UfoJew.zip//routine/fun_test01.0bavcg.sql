create
    definer = gyc@`%` function fun_test01(countryId int) returns int
begin
    declare cnum int(3);
    select count(*) into cnum from city where country_id = countryId;
    return cnum;
end;

