create definer = gyc@`%` trigger tri_insert
    after INSERT
    on emp
    for each row
begin
    insert into emp_logs(id,op,op_time,op_id,op_params)
    values(null,'insert',now(),new.id,concat('插入后(id:',NEW.id,',name:',new.name,',age:',new.age,',salary:',NEW.salary,')'));
end;

