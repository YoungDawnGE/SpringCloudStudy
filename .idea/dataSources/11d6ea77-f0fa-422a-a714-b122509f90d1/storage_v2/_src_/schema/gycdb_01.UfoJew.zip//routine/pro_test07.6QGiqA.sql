create
    definer = gyc@`%` procedure pro_test07(IN height int, OUT des varchar(50))
begin
    if height >= 180 then
        set des = '高';
    elseif height>=170 then
        set des = '中';
    else set des = '矮';
    end if ;
end;

