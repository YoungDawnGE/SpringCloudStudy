create
    definer = gyc@`%` procedure pro_test09(IN n int)
begin
    declare sum int default 0;
    declare i int default 0;
    while i<=n do
        set sum = sum + i;
        set i = i + 1;
    end while ;
    select concat('结果',sum);
end;

