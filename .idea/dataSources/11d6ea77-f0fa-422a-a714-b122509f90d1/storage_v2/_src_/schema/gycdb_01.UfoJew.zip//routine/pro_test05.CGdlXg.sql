create
    definer = gyc@`%` procedure pro_test05()
begin
        declare height int default 175;
        declare descript varchar(50);
        if height>=180 then
            set descript='身材高挑';
        elseif height>=170 then
            set descript='身材中等';
        else set descript='矮子';
        end if;
        select concat('身高',height,'对应的身材',descript);
    end;

