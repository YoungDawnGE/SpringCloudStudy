create
    definer = gyc@`%` procedure pro_test06(IN height int)
begin
        declare des varchar(50);
        if height>=180 then
            set des = '很高';
        elseif height>=170 then
            set des = '一般高';
        else set des='矮子';
        end if;
        select concat('身高',height,'对应的身材',des) as 描述;
    end;

