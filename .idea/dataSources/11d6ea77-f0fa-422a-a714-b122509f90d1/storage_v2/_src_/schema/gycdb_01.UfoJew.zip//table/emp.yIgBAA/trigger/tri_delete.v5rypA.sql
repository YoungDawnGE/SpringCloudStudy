create definer = gyc@`%` trigger tri_delete
    after DELETE
    on emp
    for each row
begin
    insert into emp_logs(id,op,op_time,op_id,op_params)
    values(null,'delete',now(),OLD.id,
           concat('删除了(id:',old.id,',name:',old.name,',age:',old.age,',salary:',old.salary,')'));
end;

