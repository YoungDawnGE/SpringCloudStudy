create
    definer = gyc@`%` procedure pro_test04()
begin
        declare num int;
        select count(*) from city into num;
        select concat('num的值为:',num);
    end;

