create
    definer = gyc@`%` procedure pro_test10(IN n int)
begin
    declare sum int default 0;
    declare i int default 0;
    REPEAT
        set sum=sum+i;
        set i=i+1;
        until i>n
    end repeat;
    select concat('结果',sum) as total;
end;

