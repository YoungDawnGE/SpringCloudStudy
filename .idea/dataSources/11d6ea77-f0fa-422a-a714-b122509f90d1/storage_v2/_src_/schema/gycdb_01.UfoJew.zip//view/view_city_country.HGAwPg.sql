create definer = gyc@`%` view view_city_country as
select `c`.`city_id`      AS `city_id`,
       `c`.`city_name`    AS `city_name`,
       `c`.`country_id`   AS `country_id`,
       `k`.`country_name` AS `country_name`
from `gycdb_01`.`city` `c`
         join `gycdb_01`.`country` `k`
where (`c`.`country_id` = `k`.`country_id`);

