create
    definer = gyc@`%` procedure pro_test03()
begin
        declare num int default 0;
        set num = num+100;
        select concat('num的值为:',num);
    end;

