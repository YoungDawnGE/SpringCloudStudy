create definer = gyc@`%` trigger tri_update
    after UPDATE
    on emp
    for each row
begin
    insert into emp_logs(id,op,op_time,op_id,op_params)
    values(null,'update',now(),new.id,
           concat('修改前(id:',old.id,',name:',old.name,',age:',old.age,',salary:',old.salary,')'));
end;

