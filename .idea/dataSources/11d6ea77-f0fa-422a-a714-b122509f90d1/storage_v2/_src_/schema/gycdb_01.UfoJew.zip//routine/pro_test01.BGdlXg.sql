create
    definer = gyc@`%` procedure pro_test01()
begin
select * from city;
select * from country;
select 'HELLO';
end;

